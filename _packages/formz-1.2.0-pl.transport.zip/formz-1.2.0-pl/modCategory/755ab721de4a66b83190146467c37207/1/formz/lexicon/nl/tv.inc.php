<?php
$_lang['formz'] = 'Formulieren';
$_lang['formz.output.properties.tpl'] = 'Formulier template';
$_lang['formz.output.properties.fieldTpl'] = 'Formulierveld template';
$_lang['formz.output.properties.fieldTypeTpl'] = 'Form Field Type Template';
$_lang['formz.output.properties.fieldWrapperTpl'] = 'Form Field Wrapper Template';
$_lang['formz.output.properties.hookPrefix'] = 'FormIt Hooks Prefix';
