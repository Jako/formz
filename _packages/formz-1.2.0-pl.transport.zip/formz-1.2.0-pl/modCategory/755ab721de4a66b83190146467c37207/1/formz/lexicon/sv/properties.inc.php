<?php
/**
 * formz
 *
 * @package formz
 */
/**
 * Properties Swedish Lexicon Entries for formz
 *
 * @package formz
 * @subpackage lexicon
 */
$_lang['prop_formz.tpl'] = 'Standard Formz mall';
$_lang['prop_formz.id'] = 'Formulär ID';
$_lang['prop_formz.field_tpl'] = 'Standard Formz fält mall';
$_lang['prop_formz.field_type_tpl'] = 'Default Formz field type template (see FormitFastPack Docs)';
$_lang['prop_formz.field_wrapper_tpl'] = 'Default Formz field wrapper template (see FormitFastPack Docs)';
