<?php

$xpdo_meta_map = array (
  'xPDOSimpleObject' => 
  array (
    0 => 'fmzForms',
    1 => 'fmzFormsFields',
    2 => 'fmzFormsValidation',
    3 => 'fmzFormsData',
    4 => 'fmzFormsDataFields',
  ),
);