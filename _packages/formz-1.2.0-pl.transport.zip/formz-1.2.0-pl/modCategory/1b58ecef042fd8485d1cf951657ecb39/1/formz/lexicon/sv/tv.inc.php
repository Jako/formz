<?php
$_lang['formz'] = 'Formz';
$_lang['formz.output.properties.tpl'] = 'Formulärmall';
$_lang['formz.output.properties.fieldTpl'] = 'Formulärfältsmall';
$_lang['formz.output.properties.fieldTypeTpl'] = 'Form Field Type Template';
$_lang['formz.output.properties.fieldWrapperTpl'] = 'Form Field Wrapper Template';
