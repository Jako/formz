<?php
$_lang['formz'] = 'Formz';
$_lang['formz.output.properties.tpl'] = 'Template de formulaire';
$_lang['formz.output.properties.fieldTpl'] = 'Template de champ de formulaire';
$_lang['formz.output.properties.fieldTypeTpl'] = 'Form Field Type Template';
$_lang['formz.output.properties.fieldWrapperTpl'] = 'Form Field Wrapper Template';
