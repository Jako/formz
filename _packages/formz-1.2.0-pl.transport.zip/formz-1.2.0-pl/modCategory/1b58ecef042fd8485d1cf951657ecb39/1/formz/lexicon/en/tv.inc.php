<?php
$_lang['formz'] = 'Formz';
$_lang['formz.output.properties.tpl'] = 'Form Template';
$_lang['formz.output.properties.fieldTpl'] = 'Form Field Template';
$_lang['formz.output.properties.fieldTypeTpl'] = 'Form Field Type Template';
$_lang['formz.output.properties.fieldWrapperTpl'] = 'Form Field Wrapper Template';
