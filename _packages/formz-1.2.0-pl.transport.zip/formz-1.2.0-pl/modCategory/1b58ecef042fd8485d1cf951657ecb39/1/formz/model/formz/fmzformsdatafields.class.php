<?php
/**
 * @package formz
 */
class fmzFormsDataFields extends xPDOSimpleObject {}