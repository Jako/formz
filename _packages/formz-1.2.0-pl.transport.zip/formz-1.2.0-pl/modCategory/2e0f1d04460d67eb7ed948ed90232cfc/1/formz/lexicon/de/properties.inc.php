<?php
/**
 * formz
 *
 * @package formz
 */
/**
 * Properties German Lexicon Entries for formz
 *
 * @package formz
 * @subpackage lexicon
 */
$_lang['prop_formz.tpl'] = 'Formz Standard Formular Template';
$_lang['prop_formz.id'] = 'Formular-ID';
$_lang['prop_formz.field_tpl'] = 'Formz Standard Formularfeld Template';
$_lang['prop_formz.field_type_tpl'] = 'Formz Standard Formularfeld-Typ Template (siehe FormitFastPack Dokumentation)';
$_lang['prop_formz.field_wrapper_tpl'] = 'Formz Standard Formularfeld-Wrapper Template (siehe FormitFastPack Dokumentation)';
