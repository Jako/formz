<?php
/**
 * @package formz
 */
class fmzFormsData extends xPDOSimpleObject {}