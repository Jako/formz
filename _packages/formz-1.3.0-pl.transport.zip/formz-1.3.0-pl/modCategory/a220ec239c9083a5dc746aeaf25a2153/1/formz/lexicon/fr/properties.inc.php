<?php
/**
 * formz
 *
 * @package formz
 */
/**
 * Properties French Lexicon Entries for formz
 *
 * @package formz
 * @subpackage lexicon
 */
$_lang['prop_formz.tpl'] = 'Modèle Formz par défaut';
$_lang['prop_formz.id'] = 'ID de formulaire';
$_lang['prop_formz.field_tpl'] = 'Champ Formz de modèle, par défaut';
$_lang['prop_formz.field_type_tpl'] = 'Default Formz field type template (see FormitFastPack Docs)';
$_lang['prop_formz.field_wrapper_tpl'] = 'Default Formz field wrapper template (see FormitFastPack Docs)';
