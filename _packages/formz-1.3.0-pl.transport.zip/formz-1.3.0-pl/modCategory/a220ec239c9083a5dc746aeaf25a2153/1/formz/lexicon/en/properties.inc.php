<?php
/**
 * formz
 *
 * @package formz
 */
/**
 * Properties English Lexicon Entries for formz
 *
 * @package formz
 * @subpackage lexicon
 */
$_lang['prop_formz.tpl'] = 'Default Formz form template';
$_lang['prop_formz.id'] = 'Form ID';
$_lang['prop_formz.field_tpl'] = 'Default Formz field template';
$_lang['prop_formz.field_type_tpl'] = 'Default Formz field type template (see FormitFastPack Docs)';
$_lang['prop_formz.field_wrapper_tpl'] = 'Default Formz field wrapper template (see FormitFastPack Docs)';
