<?php
$_lang['formz'] = 'Formz';
$_lang['formz.output.properties.tpl'] = 'Formular-Template';
$_lang['formz.output.properties.fieldTpl'] = 'Formularfeld-Template';
$_lang['formz.output.properties.fieldTypeTpl'] = 'Formularfeld-Typ-Template';
$_lang['formz.output.properties.fieldWrapTpl'] = 'Formularfeld-Wrapper-Template';
$_lang['formz.output.properties.hookPrefix'] = 'FormIt Hooks Prefix';
