# Formz

Formz is a UI form builder that allows website managers and developers alike to 
easily create web forms. It was built to allow the website manager to create 
web forms to collect information and store it in the database and receive via 
email. This Add-on should be valuable to Developer and Website manager alike, 
as it gives a easy way for Developers to create a FormIt form and store/email 
the data to the website manager in a easy to manage way.

### Requirements

* MODX Revolution 2.2.4+
* [FormIt](http://modx.com/extras/package/formit)
* [FormitFastPack](http://modx.com/extras/package/formitfastpack)
